#include "all.hpp"

void jordan(int n,double* A,double* b,double* x, int* flag){
    int* check;
    check=new int[n];
    for (int i=0;i<n;i++){
        double max=0;
        int maxn=0;
        for (int j=0;j<n;j++){
            int ch=0;
            for (int k=0;k<i;k++){
                if (j==check[k]) ch=1;
            }
            if ((abs(A[j*n+i])>abs(max))&&(ch==0)){
                max=A[j*n+i];
                maxn=j;
            }
        }
        check[i]=maxn;
        if (max==0){
            *flag=1;
            break;
        }
        for (int j=i;j<n;j++){
            A[maxn*n+j]/=max;
        }
        b[maxn]/=max;
        for (int j=0;j<n;j++){
            if (j!=maxn){
                double z=A[j*n+i];
                for (int k=i;k<n;k++){
                    A[j*n+k]-=A[maxn*n+k]*z;
                }
                b[j]-=b[maxn]*z;
            }
        }
    }
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            if (A[i*n+j]==1){
                x[j]=b[i];
            }
            if (abs(x[j])<0.0000001){
                x[j]=0;
            }
        }
    }
}
