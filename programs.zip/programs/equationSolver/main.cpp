#include "main.hpp"

double norm(int,double*,double*,double*);

int main(){
    int n,i,j;
    char c;
    int flag=0;
    cin>>n;
    string inname="";
    ofstream out("/Users/mihailkondrasin/Desktop/ЭВМ/z1/output.txt");
    double* A;
    double* b;
    double* x;
    A=new double[n*n];
    b=new double[n];
    x=new double[n];
    
    while ((c=cin.get())!='\n'){
        if (c!=' ') inname+=c;
    }
    clock_t start_time=clock();
    if (inname==""){
        evf(A,n);
    }else{
        eff(inname,A,n,&flag);
    }
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            cout<<A[i*n+j]<<' ';
        }
        cout<<endl;
    }
    for (i=0;i<n;i++){
        b[i]=0;
        if (i==n-1) b[i]=1;
    }
    jordan(n,A,b,x,&flag);
    if (flag==0){
        for (i=0;i<n;i++){
            out<<x[i]<<' ';
        }
        out<<endl;
        out<<"Norm: "<<norm(n,A,b,x)<<endl;
    }else{
        out<<"bad..."<<endl;
    }
    clock_t stop_time=clock();
    double duration = (stop_time - start_time);
    out << "Duration: " << duration << endl;
    
    out.close();
    delete [] A;
    delete [] b;
    delete [] x;
    
    return 0;
}

double norm(int n,double* A, double* b, double* x){
    double result=0;
    double term;
    for (int i=0;i<n;i++){
        term=0;
        for (int j=0;j<n;j++){
            term+=A[i*n+j]*x[j];
        }
        term-=b[i];
        result+=term*term;
    }
    return sqrt(result);
}
