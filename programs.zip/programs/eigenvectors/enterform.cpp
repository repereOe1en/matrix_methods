#include "all.hpp"

void evf(double* A,int n){
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            if (i==n-1){
                A[i*n+j]=j+1;
            }
            if (j==n-1){
                A[i*n+j]=i+1;
            }
            if (i==j){
                A[i*n+j]=1;
            }
        }
    }
    A[n*n-1]=n;
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            cout<<A[i*n+j]<<' ';
        }
        cout<<endl;
    }
}
