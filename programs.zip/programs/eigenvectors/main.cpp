#include "main.hpp"

int main(){
    int n,i,j;
    char c;
    int flag=0;
    cin>>n;
    string inname="";
    ofstream out("/Users/mihailkondrasin/Desktop/ЭВМ/z2/output.txt");
    double tr1=0;
    double len1=0;
    double tr2=0;
    double len2=0;
    double* A;
    double* x;
    double* x1;
    double* x2;
    double epsilon=1e-10;
    A=new double[n*n];
    x=new double[n];
    x1=new double[n];
    x2=new double[n];
    
    while ((c=cin.get())!='\n'){
        if (c!=' ') inname+=c;
    }
    clock_t start_time=clock();
    if (inname==""){
        evf(A,n);
    }else{
        eff(inname,A,n,&flag);
    }

    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            if (i==j){
                tr1+=A[i*n+j];
            }
            len1+=A[i*n+j]*A[i*n+j];
        }
    }
    len1=sqrt(len1);

    sobstv(n, A, x, epsilon,x1, x2, &flag);


    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            if (i==j){
                tr2+=A[i*n+j];
            }
            len2+=A[i*n+j]*A[i*n+j];
        }
    }
    len2=sqrt(len2);

    for (i=0;i<n;i++){
        if (abs(x[i])>epsilon){
            out << x[i] << ' ';
        }else{
            out << 0<<' ';
        }
    }
    out<<endl;
    clock_t stop_time=clock();
    double duration = (stop_time - start_time);
    out << "Duration: " << duration << endl;
    out << abs(tr1-tr2)<<' '<<abs(len1-len2);
    out.close();
    delete [] A;
    delete [] x;
    delete [] x1;
    delete [] x2;
    
    return 0;
}
