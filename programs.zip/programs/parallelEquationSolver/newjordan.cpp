#include "all.hpp"
#include <thread>
#include <vector>
void maxnum(int n,double* A, int start, int stop,int &result,int col,int* check){
    int indic=0;
    int count=start;
    for (int i=0;i<n;i++){
        if (count==check[i]){
            indic=1;
        }
    }
    while (indic==1){
        indic=0;
        count++;
        for (int i=0;i<n;i++){
            if (count==check[i]){
                indic=1;
            }
        }
    }
    result=count;
    for (int j=count+1;j<stop;j++) {
        indic=0;
        for (int i=0;i<n;i++){
            if (j==check[i]){
                indic=1;
                break;
            }
        }
        if ((abs(A[j * n+col]) > abs(A[result * n+col])) && (indic==0)) {
            result = j;
        }
    }
}
void elim(int n,double* A,double* b,int start,int stop,int maxn,int col){
    double tmp;
    for (int i=start;i<stop;i++){
        if (i!=maxn) {
            tmp=-A[i * n+col];
            for (int j = col; j < n; j++) {
                A[i * n + j] += A[maxn * n + j] * (tmp/ A[maxn * n+col]);
            }
            b[i]+=b[maxn]*(tmp/A[maxn*n+col]);
        }
    }
}

void jordan(int n,double* A,double* b,double* x,int threadnum){
    int k;
    int maxn;
    int* check;
    check=new int[n];
    for (int i=0;i<n;i++){
        check[i]=-1;
    }
    vector<thread> threads;
    vector<int> maxnums;
    for (int i=0;i<n;i++) {
        threads.clear();
        maxnums.clear();
        for (k = 0; k < threadnum; k++) maxnums.push_back(0);
        for (k = 0; k < threadnum; k++) {
            threads.emplace_back(maxnum, n, A, n * k / threadnum, n * (k + 1) / threadnum, std::ref(maxnums[k]),i,check);
        }
        for (k = 0; k < threadnum; k++) {
            threads[k].join();
        }
        maxn = maxnums[0];
        for (k = 1; k < threadnum; k++) {
            if (abs(A[maxn * n+i]) < abs(A[maxnums[k] * n+i])) {
                maxn = maxnums[k];
            }
        }
        check[i]=maxn;
        threads.clear();
        for (k = 0; k < threadnum; k++) {
            threads.emplace_back(elim, n, std::ref(A), std::ref(b), n * k / threadnum, n * (k + 1) / threadnum, maxn,i);
        }
        for (k = 0; k < threadnum; k++) {
            threads[k].join();
        }
    }
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            if (A[i*n+j]!=0){
                x[j]=b[j]/A[i*n+j];
                break;
            }
        }
    }
}