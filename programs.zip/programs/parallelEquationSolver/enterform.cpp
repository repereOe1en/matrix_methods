#include "all.hpp"

void evf(double* A,int n){
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            if (abs(i-j)==1) A[i*n+j]=1;
            else if (i==j) A[i*n+j]=-2;
            else A[i*n+j]=0;
        }
    }
    A[0]=-1;
    double dn=n;
    A[n*n-1]=-(dn-1)/dn;
}
