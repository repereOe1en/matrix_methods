#include "main.hpp"

double norm(int,double*,double*,double*);

int main(){
    int n,i;
    int threadnum;
    char c;
    int flag=0;
    cin>>threadnum;
    cin>>n;
    string inname="";
    ofstream out("/Users/mihailkondrasin/Desktop/ЭВМ/z3/output.txt");
    double* A;
    double* b;
    double* x;
    A=new double[n*n];
    b=new double[n];
    x=new double[n];
    
    while ((c=cin.get())!='\n'){
        if (c!=' ') inname+=c;
    }
    if (inname==""){
        evf(A,n);
    }else{
        eff(inname,A,n,&flag);
    }
    for (i=0;i<n-1;i++){
        b[i]=0;
    }
    b[n-1]=1;
    auto start = std::chrono::high_resolution_clock::now();
    jordan(n,A,b,x,threadnum);
    auto stop = std::chrono::high_resolution_clock::now();
    if (flag==0){
        for (i=0;i<n;i++){
            out<<x[i]<<' ';
        }
        out<<endl;
        out<<"Norm: "<<norm(n,A,b,x)<<endl;
    }else{
        out<<"bad..."<<endl;
    }
    auto duration = duration_cast<std::chrono::microseconds>(stop - start);
    double dur=duration.count();
    out << "Duration: " << dur/1000000 << endl;
    
    out.close();
    delete [] A;
    delete [] b;
    delete [] x;
    
    return 0;
}

double norm(int n,double* A, double* b, double* x){
    double result=0;
    double term;
    for (int i=0;i<n;i++){
        term=0;
        for (int j=0;j<n;j++){
            term+=A[i*n+j]*x[j];
        }
        term-=b[i];
        result+=term*term;
    }
    return sqrt(result);
}
