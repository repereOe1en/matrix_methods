#include <iostream>
#include <string>
#include <fstream>
#include <math.h>
#include <ctime>
#include <chrono>

#include "enterfile.cpp"
#include "enterform.cpp"
#include "newjordan.cpp"

using namespace std;
