#include "all.hpp"

void eff(string inname,double* A,int n,int* flag){
    ifstream fin("/Users/mihailkondrasin/Desktop/ЭВМ/z3/"+inname);
    if (!fin.is_open()) *flag=1;
    for (int i=0;i<n*n;i++) {
        if (fin >> A[i]);
        else{
            *flag=1;
            break;
        }
    }
    fin.close();
}
